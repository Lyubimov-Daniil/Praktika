<?php


class LessonPlanMap extends BaseMap
{


}