<?php


class StudentMap extends BaseMap
{

}