<?php


class OtdelMap extends BaseMap
{
}