<?php


class GruppaMap extends BaseMap
{

}