<?php


class ScheduleMap extends BaseMap
{

}