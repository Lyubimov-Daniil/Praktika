<?php


class SubjectMap extends BaseMap
{

}