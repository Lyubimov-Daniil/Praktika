<?php


class ClassroomMap extends BaseMap
{
}