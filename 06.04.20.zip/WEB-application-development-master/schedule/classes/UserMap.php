<?php


class UserMap extends BaseMap
{
}