<?php
require_once 'template/header.php';
require_once 'template/footer.php';